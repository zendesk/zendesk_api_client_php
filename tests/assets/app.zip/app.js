(function() {
    return {
        requests: {
            getMe: function() {
                return {
                    url: '/api/v2/users/me.json'
                };
            }
        },

        events: {
            'app.created': 'onAppCreated',
            //'pane.activated': 'onAppCreated',
            'getMe.done': 'getMe_done'
        },

        onAppCreated: function(event) {
            this.ajax('getMe');
        },

        getMe_done: function(data) {
            this.$('[data-main]').text(JSON.stringify( data ));
        }
    };
})();
